import type { Company, Contact, Deal, Organization, Pipeline, Stage, Task } from './types'

export const demoOrg: Organization = { id: 'demo-org', name: 'Empresa Demonstração' }
export const demoPipeline: Pipeline = { id: 'demo-pipeline', organization_id: demoOrg.id, name: 'Pipeline Comercial', is_default: true }
export const demoStages: Stage[] = [
  ['novo','Novo Lead',1,10], ['contato','Contato',2,25], ['qualificado','Qualificado',3,50],
  ['proposta','Proposta',4,70], ['negociacao','Negociação',5,85], ['fechado','Fechado',6,100]
].map(([id,name,position,probability]) => ({ id:String(id), organization_id:demoOrg.id, pipeline_id:demoPipeline.id, name:String(name), position:Number(position), probability:Number(probability) }))
export const demoCompanies: Company[] = [
  { id:'co1', organization_id:demoOrg.id, name:'Kero Motors', phone:'(91) 99999-0001', email:'comercial@keromotors.com' },
  { id:'co2', organization_id:demoOrg.id, name:'Delicatta Modulados', phone:'(91) 99999-0002', email:'contato@delicatta.com' },
]
export const demoContacts: Contact[] = [
  { id:'c1', organization_id:demoOrg.id, name:'João Silva', phone:'(91) 98888-1111', whatsapp:'(91) 98888-1111', email:'joao@email.com', source:'Instagram', status:'lead', tags:['quente'] },
  { id:'c2', organization_id:demoOrg.id, name:'Mariana Costa', phone:'(91) 97777-2222', whatsapp:'(91) 97777-2222', email:'mariana@email.com', source:'WhatsApp', status:'lead', tags:['financiamento'] },
  { id:'c3', organization_id:demoOrg.id, name:'Carlos Souza', phone:'(91) 96666-3333', email:'carlos@email.com', source:'Site', status:'cliente', tags:['recorrente'] },
]
export const demoDeals: Deal[] = [
  { id:'d1', organization_id:demoOrg.id, pipeline_id:demoPipeline.id, stage_id:'novo', contact_id:'c1', title:'Evoque 2013', value:77900, currency:'BRL', status:'open' },
  { id:'d2', organization_id:demoOrg.id, pipeline_id:demoPipeline.id, stage_id:'qualificado', contact_id:'c2', title:'Projeto planejados', value:32000, currency:'BRL', status:'open' },
  { id:'d3', organization_id:demoOrg.id, pipeline_id:demoPipeline.id, stage_id:'proposta', contact_id:'c3', title:'CRM anual', value:7200, currency:'BRL', status:'open' },
]
export const demoTasks: Task[] = [
  { id:'t1', organization_id:demoOrg.id, title:'Ligar para João', due_at:new Date(Date.now()+3600000).toISOString(), status:'pending', priority:'high', contact_id:'c1' },
  { id:'t2', organization_id:demoOrg.id, title:'Enviar proposta para Mariana', due_at:new Date(Date.now()+86400000).toISOString(), status:'pending', priority:'medium', contact_id:'c2' },
]
