create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.organization_members (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','admin','manager','member')),
  created_at timestamptz not null default now(),
  unique (organization_id,user_id)
);

create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(), organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null, website text, phone text, email text, owner_id uuid references auth.users(id),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.contacts (
  id uuid primary key default gen_random_uuid(), organization_id uuid not null references public.organizations(id) on delete cascade,
  company_id uuid references public.companies(id) on delete set null, owner_id uuid references auth.users(id),
  name text not null, email text, phone text, whatsapp text, instagram text, source text, status text not null default 'lead',
  tags text[] not null default '{}', metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.pipelines (
  id uuid primary key default gen_random_uuid(), organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null, is_default boolean not null default false, created_at timestamptz not null default now()
);
create table if not exists public.pipeline_stages (
  id uuid primary key default gen_random_uuid(), organization_id uuid not null references public.organizations(id) on delete cascade,
  pipeline_id uuid not null references public.pipelines(id) on delete cascade, name text not null, position integer not null,
  probability integer not null default 0 check(probability between 0 and 100), unique(pipeline_id,position)
);
create table if not exists public.deals (
  id uuid primary key default gen_random_uuid(), organization_id uuid not null references public.organizations(id) on delete cascade,
  pipeline_id uuid not null references public.pipelines(id), stage_id uuid not null references public.pipeline_stages(id),
  contact_id uuid references public.contacts(id) on delete set null, company_id uuid references public.companies(id) on delete set null,
  owner_id uuid references auth.users(id), title text not null, value numeric(14,2) not null default 0, currency text not null default 'BRL',
  status text not null default 'open' check(status in ('open','won','lost')), expected_close_date date, lost_reason text,
  metadata jsonb not null default '{}'::jsonb, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(), organization_id uuid not null references public.organizations(id) on delete cascade,
  assigned_to uuid references auth.users(id), contact_id uuid references public.contacts(id) on delete cascade, deal_id uuid references public.deals(id) on delete cascade,
  title text not null, description text, due_at timestamptz, status text not null default 'pending' check(status in ('pending','done','cancelled')),
  priority text not null default 'medium' check(priority in ('low','medium','high')), created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.notes (
  id uuid primary key default gen_random_uuid(), organization_id uuid not null references public.organizations(id) on delete cascade,
  author_id uuid not null references auth.users(id), contact_id uuid references public.contacts(id) on delete cascade, deal_id uuid references public.deals(id) on delete cascade,
  body text not null, created_at timestamptz not null default now()
);
create table if not exists public.activities (
  id uuid primary key default gen_random_uuid(), organization_id uuid not null references public.organizations(id) on delete cascade,
  actor_id uuid references auth.users(id), contact_id uuid references public.contacts(id) on delete cascade, deal_id uuid references public.deals(id) on delete cascade,
  activity_type text not null, title text not null, description text, data jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);

create index if not exists organization_members_user_idx on public.organization_members(user_id);
create index if not exists contacts_org_idx on public.contacts(organization_id);
create index if not exists deals_org_idx on public.deals(organization_id);
create index if not exists deals_stage_idx on public.deals(stage_id);
create index if not exists tasks_org_due_idx on public.tasks(organization_id,due_at);

create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.profiles(id,full_name) values(new.id,coalesce(new.raw_user_meta_data->>'full_name',new.email)) on conflict(id) do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create or replace function public.is_org_member(org_id uuid) returns boolean language sql stable security definer set search_path=public as $$
select exists(select 1 from public.organization_members m where m.organization_id=org_id and m.user_id=auth.uid()); $$;
create or replace function public.is_org_admin(org_id uuid) returns boolean language sql stable security definer set search_path=public as $$
select exists(select 1 from public.organization_members m where m.organization_id=org_id and m.user_id=auth.uid() and m.role in ('owner','admin')); $$;

create or replace function public.create_organization(org_name text) returns uuid language plpgsql security definer set search_path=public as $$
declare org_id uuid; pipe_id uuid;
begin
  if auth.uid() is null then raise exception 'Not authenticated'; end if;
  if nullif(trim(org_name),'') is null then raise exception 'Organization name is required'; end if;
  insert into public.organizations(name,created_by) values(trim(org_name),auth.uid()) returning id into org_id;
  insert into public.organization_members(organization_id,user_id,role) values(org_id,auth.uid(),'owner');
  insert into public.pipelines(organization_id,name,is_default) values(org_id,'Pipeline Comercial',true) returning id into pipe_id;
  insert into public.pipeline_stages(organization_id,pipeline_id,name,position,probability) values
    (org_id,pipe_id,'Novo Lead',1,10),(org_id,pipe_id,'Contato',2,25),(org_id,pipe_id,'Qualificado',3,50),
    (org_id,pipe_id,'Proposta',4,70),(org_id,pipe_id,'Negociação',5,85),(org_id,pipe_id,'Fechado',6,100);
  return org_id;
end; $$;
grant execute on function public.create_organization(text) to authenticated;

alter table public.profiles enable row level security;
alter table public.organizations enable row level security;
alter table public.organization_members enable row level security;
alter table public.companies enable row level security;
alter table public.contacts enable row level security;
alter table public.pipelines enable row level security;
alter table public.pipeline_stages enable row level security;
alter table public.deals enable row level security;
alter table public.tasks enable row level security;
alter table public.notes enable row level security;
alter table public.activities enable row level security;

do $$ begin
  if not exists(select 1 from pg_policies where schemaname='public' and tablename='profiles' and policyname='profiles_self') then
    create policy profiles_self on public.profiles for select to authenticated using(id=auth.uid());
    create policy profiles_update_self on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
  end if;
end $$;

do $$ declare t text; begin
  foreach t in array array['companies','contacts','pipelines','pipeline_stages','deals','tasks','notes','activities'] loop
    execute format('create policy %I on public.%I for select to authenticated using(public.is_org_member(organization_id))',t||'_select',t);
    execute format('create policy %I on public.%I for insert to authenticated with check(public.is_org_member(organization_id))',t||'_insert',t);
    execute format('create policy %I on public.%I for update to authenticated using(public.is_org_member(organization_id)) with check(public.is_org_member(organization_id))',t||'_update',t);
    execute format('create policy %I on public.%I for delete to authenticated using(public.is_org_member(organization_id))',t||'_delete',t);
  end loop;
exception when duplicate_object then null; end $$;

do $$ begin
  create policy organizations_select on public.organizations for select to authenticated using(public.is_org_member(id));
exception when duplicate_object then null; end $$;
do $$ begin
  create policy organizations_update on public.organizations for update to authenticated using(public.is_org_admin(id)) with check(public.is_org_admin(id));
exception when duplicate_object then null; end $$;
do $$ begin
  create policy members_select on public.organization_members for select to authenticated using(public.is_org_member(organization_id));
exception when duplicate_object then null; end $$;
do $$ begin
  create policy members_insert on public.organization_members for insert to authenticated with check(public.is_org_admin(organization_id));
exception when duplicate_object then null; end $$;
do $$ begin
  create policy members_update on public.organization_members for update to authenticated using(public.is_org_admin(organization_id)) with check(public.is_org_admin(organization_id));
exception when duplicate_object then null; end $$;
do $$ begin
  create policy members_delete on public.organization_members for delete to authenticated using(public.is_org_admin(organization_id));
exception when duplicate_object then null; end $$;
